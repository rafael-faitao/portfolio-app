(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/_next-internal_server_app_api_chat_route_actions_cf3bea7b.js", {

"[project]/.next-internal/server/app/api/chat/route/actions.js [app-edge-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=_next-internal_server_app_api_chat_route_actions_cf3bea7b.js.map
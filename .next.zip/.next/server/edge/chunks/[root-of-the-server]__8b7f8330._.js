(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[root-of-the-server]__8b7f8330._.js", {

"[externals]/node:buffer [external] (node:buffer, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[project]/src/lib/openai.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "CHAT_MODEL": ()=>CHAT_MODEL,
    "EMBED_MODEL": ()=>EMBED_MODEL,
    "openai": ()=>openai
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$index$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/index.mjs [app-edge-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/client.mjs [app-edge-route] (ecmascript) <export OpenAI as default>");
;
const openai = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__["default"]({
    apiKey: process.env.OPENAI_API_KEY
});
const CHAT_MODEL = process.env.AI_MODEL || "gpt-4o-mini";
const EMBED_MODEL = process.env.EMBED_MODEL || "text-embedding-3-small";
}),
"[project]/ [app-edge-route] (unsupported edge import fs, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
__turbopack_context__.n(__import_unsupported(`fs`));
}}),
"[project]/ [app-edge-route] (unsupported edge import path, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
__turbopack_context__.n(__import_unsupported(`path`));
}}),
"[project]/src/lib/rag.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "buildSystemPrompt": ()=>buildSystemPrompt,
    "search": ()=>search
});
var __TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__fs$2c$__ecmascript$29$__ = __turbopack_context__.i("[project]/ [app-edge-route] (unsupported edge import fs, ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__path$2c$__ecmascript$29$__ = __turbopack_context__.i("[project]/ [app-edge-route] (unsupported edge import path, ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/openai.ts [app-edge-route] (ecmascript)");
;
;
;
const DOCS_DIR = __TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__path$2c$__ecmascript$29$__["default"].join(process.cwd(), "data", "docs");
let CHUNKS = null;
async function embed(texts) {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["openai"].embeddings.create({
        model: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["EMBED_MODEL"],
        input: texts
    });
    return data.map((d)=>d.embedding);
}
function cosine(a, b) {
    const dot = a.reduce((s, v, i)=>s + v * b[i], 0);
    const na = Math.sqrt(a.reduce((s, v)=>s + v * v, 0));
    const nb = Math.sqrt(b.reduce((s, v)=>s + v * v, 0));
    return dot / (na * nb);
}
function chunk(text, size = 900, overlap = 150) {
    const out = [];
    let i = 0;
    while(i < text.length){
        out.push(text.slice(i, i + size));
        i += size - overlap;
    }
    return out;
}
async function loadChunks() {
    const files = (0, __TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__fs$2c$__ecmascript$29$__["readdirSync"])(DOCS_DIR).filter((f)=>f.endsWith(".md"));
    const rawChunks = [];
    for (const f of files){
        const full = (0, __TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__fs$2c$__ecmascript$29$__["readFileSync"])(__TURBOPACK__imported__module__$5b$project$5d2f$__$5b$app$2d$edge$2d$route$5d$__$28$unsupported__edge__import__path$2c$__ecmascript$29$__["default"].join(DOCS_DIR, f), "utf8");
        const parts = chunk(full);
        parts.forEach((t, idx)=>rawChunks.push({
                id: `${f}#${idx}`,
                text: t
            }));
    }
    const vectors = await embed(rawChunks.map((c)=>c.text));
    CHUNKS = rawChunks.map((c, i)=>({
            ...c,
            vector: vectors[i]
        }));
}
async function search(query, k = 6) {
    if (!CHUNKS) await loadChunks();
    const [qVec] = await embed([
        query
    ]);
    const scored = CHUNKS.map((c)=>({
            c,
            score: cosine(qVec, c.vector)
        }));
    scored.sort((a, b)=>b.score - a.score);
    return scored.slice(0, k).map((s)=>s.c);
}
function buildSystemPrompt(lang = "pt-BR") {
    const isPT = lang.toLowerCase().startsWith("pt");
    return isPT ? `Você é o assistente do site do portfólio de ${process.env.SITE_OWNER_NAME ?? "Rafael"}.
Responda de forma objetiva e útil. Se algo não estiver nos dados, diga que não tem certeza.
Se a pergunta for sobre carreira do visitante, ajude brevemente e convide para falar com ${process.env.SITE_OWNER_NAME ?? "Rafael"}.` : `You are the portfolio site's assistant for ${process.env.SITE_OWNER_NAME ?? "Rafael"}.
Answer concisely and helpfully. If unsure due to missing data, say so.
If the visitor asks career questions, help briefly and invite them to contact ${process.env.SITE_OWNER_NAME ?? "Rafael"}.`;
}
}),
"[project]/src/data/profile.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "profile": ()=>profile
});
const profile = {
    name: process.env.SITE_OWNER_NAME || "Rafael Oliveira",
    title: "Full‑Stack Software Engineer",
    location: "Rio de Janero, Brazil",
    languages: [
        "Portuguese",
        "English",
        "French (basic)"
    ],
    summary: `Senior full‑stack dev (React/Angular/Node/.NET). Focused on performance, DX, and shipping.
  Built edtech apps, real‑time audio transcription, and AI assistants. Interested in ML/RAG.`,
    highlights: [
        "9+ years web (React, Angular, Node)",
        "AI/RAG prototypes and tooling",
        "Microservices, queues, Redis, perf tuning"
    ],
    links: [
        {
            label: "LinkedIn",
            url: "https://www.linkedin.com/in/rafael-oliveiraf"
        },
        {
            label: "GitHub",
            url: "https://github.com/rafael-faitao"
        }
    ]
};
}),
"[project]/src/app/api/chat/route.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "POST": ()=>POST,
    "runtime": ()=>runtime
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [app-edge-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/spec-extension/response.js [app-edge-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/openai.ts [app-edge-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rag$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rag.ts [app-edge-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$profile$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/profile.ts [app-edge-route] (ecmascript)");
;
;
;
;
const runtime = "edge"; // fast, low‑latency
async function POST(req) {
    console.log('test');
    try {
        const { messages, lang } = await req.json();
        const lastUser = messages?.filter((m)=>m.role === "user").pop();
        const q = lastUser?.content ?? "";
        const top = q ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rag$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["search"])(q, 6) : [];
        const context = [
            `PROFILE: ${JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$profile$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["profile"])}`,
            `DOCS:\n${top.map((c)=>`[#${c.id}]\n${c.text}`).join("\n\n")}`
        ].join("\n\n");
        const sys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rag$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["buildSystemPrompt"])(lang ?? process.env.SITE_LANG ?? "pt-BR");
        const completion = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["openai"].chat.completions.create({
            model: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$openai$2e$ts__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["CHAT_MODEL"],
            temperature: 0.2,
            messages: [
                {
                    role: "system",
                    content: sys
                },
                {
                    role: "system",
                    content: `Use only this context. If the answer isn't in here, say you don't know.\n\n${context}`
                },
                ...messages
            ]
        });
        console.dir('completion', completion);
        const text = completion.choices?.[0]?.message?.content ?? "";
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            reply: text
        }, {
            status: 200
        });
    } catch (e) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: e.message ?? "Unknown error"
        }, {
            status: 500
        });
    }
}
}),
}]);

//# sourceMappingURL=%5Broot-of-the-server%5D__8b7f8330._.js.map
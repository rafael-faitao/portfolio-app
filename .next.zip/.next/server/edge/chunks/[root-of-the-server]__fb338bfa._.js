(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[root-of-the-server]__fb338bfa._.js", {

"[externals]/node:buffer [external] (node:buffer, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[project]/src/app/api/chat/route.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "POST": ()=>POST,
    "runtime": ()=>runtime
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [app-edge-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/spec-extension/response.js [app-edge-route] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/lib/openai'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/lib/rag'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/data/profile'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
;
;
;
const runtime = "edge"; // fast, low‑latency
async function POST(req) {
    try {
        const { messages, lang } = await req.json();
        const lastUser = messages?.filter((m)=>m.role === "user").pop();
        const q = lastUser?.content ?? "";
        const top = q ? await search(q, 6) : [];
        const context = [
            `PROFILE: ${JSON.stringify(profile)}`,
            `DOCS:\n${top.map((c)=>`[#${c.id}]\n${c.text}`).join("\n\n")}`
        ].join("\n\n");
        const sys = buildSystemPrompt(lang ?? process.env.SITE_LANG ?? "pt-BR");
        const completion = await openai.chat.completions.create({
            model: CHAT_MODEL,
            temperature: 0.2,
            messages: [
                {
                    role: "system",
                    content: sys
                },
                {
                    role: "system",
                    content: `Use only this context. If the answer isn't in here, say you don't know.\n\n${context}`
                },
                ...messages
            ]
        });
        const text = completion.choices?.[0]?.message?.content ?? "";
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            reply: text
        }, {
            status: 200
        });
    } catch (e) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: e.message ?? "Unknown error"
        }, {
            status: 500
        });
    }
}
}),
}]);

//# sourceMappingURL=%5Broot-of-the-server%5D__fb338bfa._.js.map
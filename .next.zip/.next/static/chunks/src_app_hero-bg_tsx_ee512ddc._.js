(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/hero-bg.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>HeroBg
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/build/three.core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/three/build/three.module.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$EffectComposer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/examples/jsm/postprocessing/EffectComposer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$RenderPass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/examples/jsm/postprocessing/RenderPass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$UnrealBloomPass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/three/examples/jsm/postprocessing/UnrealBloomPass.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function HeroBg() {
    _s();
    const mountRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeroBg.useEffect": ()=>{
            // Scene, Camera, Renderer
            const scene = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Scene"]();
            let camera;
            const renderer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["WebGLRenderer"]({
                antialias: true,
                alpha: true
            });
            renderer.setClearColor(0x000000, 0); // Transparent background
            renderer.setPixelRatio(window.devicePixelRatio);
            renderer.setSize(window.innerWidth, window.innerHeight);
            mountRef.current.appendChild(renderer.domElement);
            // Postprocessing: Bloom
            const composer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$EffectComposer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EffectComposer"](renderer);
            composer.renderer.setClearColor(0x000000, 0); // Also set composer to transparent
            camera = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OrthographicCamera"](-12 * (window.innerWidth / window.innerHeight) / 2, 12 * (window.innerWidth / window.innerHeight) / 2, 12 / 2, -12 / 2, 0.1, 1000);
            camera.position.set(12, 12, 10); // Move camera to top-right and above
            camera.lookAt(0, 0, 0); // Look at the center
            composer.addPass(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$RenderPass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderPass"](scene, camera));
            composer.addPass(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$examples$2f$jsm$2f$postprocessing$2f$UnrealBloomPass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnrealBloomPass"](new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vector2"](window.innerWidth, window.innerHeight), 1.2, 0.6, 0.01));
            // Cube geometry and material
            const geometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BoxGeometry"](1, 1, 1);
            const edgeGeometry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EdgesGeometry"](geometry);
            const edgeMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineBasicMaterial"]({
                color: 0xffffff
            });
            // Helper to add Angular logo
            function addLogo(parent) {
                const loader = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextureLoader"]();
                const angularTexture = loader.load('/images/ang.svg');
                const logoMaterial = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshBasicMaterial"]({
                    map: angularTexture,
                    transparent: true
                });
                const logoPlane = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mesh"](new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlaneGeometry"](0.7, 0.7), logoMaterial);
                logoPlane.position.set(0, 0, -0.075);
                parent.add(logoPlane);
            }
            // Top-right cube
            const cube1 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            cube1.position.set(6.8, 6.8, 0);
            cube1.rotation.x = Math.PI * 0.18;
            cube1.rotation.y = -Math.PI * 0.18;
            cube1.rotation.z = Math.PI * 0.08;
            scene.add(cube1);
            addLogo(cube1);
            // Bottom-right T-shaped block
            const cube3 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            cube3.position.set(6.8, -6.8, 0);
            cube3.rotation.x = Math.PI * 0.18;
            cube3.rotation.y = 0;
            cube3.rotation.z = 0;
            scene.add(cube3);
            addLogo(cube3);
            // T children
            const tChildTop = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            tChildTop.position.set(0, 1, 0);
            cube3.add(tChildTop);
            const tChildLeft = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            tChildLeft.position.set(-1, 0, 0);
            cube3.add(tChildLeft);
            const tChildRight = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            tChildRight.position.set(1, 0, 0);
            cube3.add(tChildRight);
            // Bottom-left L-shaped block
            const cube2 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            cube2.position.set(-6.8, -6.8, 0);
            cube2.rotation.x = Math.PI * 0.18;
            cube2.rotation.y = Math.PI * 0.18;
            cube2.rotation.z = -Math.PI * 0.08;
            scene.add(cube2);
            addLogo(cube2);
            // L children
            const lChildTop2 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            lChildTop2.position.set(0, 1, 0);
            cube2.add(lChildTop2);
            const lChildTop1 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            lChildTop1.position.set(0, 2, 0);
            cube2.add(lChildTop1);
            const lChildRight = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$three$2f$build$2f$three$2e$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineSegments"](edgeGeometry, edgeMaterial);
            lChildRight.position.set(1, 0, 0);
            cube2.add(lChildRight);
            // Animation
            let mouseX = 0, mouseY = 0;
            let targetRotX = [
                Math.PI * 0.18,
                Math.PI * 0.18,
                Math.PI * 0.18
            ];
            let targetRotY = [
                -Math.PI * 0.18,
                Math.PI * 0.18,
                0
            ];
            let baseRotZ = [
                Math.PI * 0.08,
                -Math.PI * 0.08,
                0
            ];
            const cubes = [
                cube1,
                cube2,
                cube3
            ];
            function animate() {
                cubes.forEach({
                    "HeroBg.useEffect.animate": (cube, i)=>{
                        cube.rotation.x += (targetRotX[i] - cube.rotation.x) * 0.08;
                        cube.rotation.y += (targetRotY[i] - cube.rotation.y) * 0.08;
                        cube.rotation.z = baseRotZ[i];
                    }
                }["HeroBg.useEffect.animate"]);
                composer.render();
                requestAnimationFrame(animate);
            }
            animate();
            function handleResize() {
                camera.left = -12 * (window.innerWidth / window.innerHeight) / 2;
                camera.right = 12 * (window.innerWidth / window.innerHeight) / 2;
                camera.top = 12 / 2;
                camera.bottom = -12 / 2;
                camera.updateProjectionMatrix();
                renderer.setSize(window.innerWidth, window.innerHeight);
                composer.setSize(window.innerWidth, window.innerHeight);
            }
            window.addEventListener('resize', handleResize);
            function handleMouseMove(event) {
                mouseX = event.clientX / window.innerWidth * 2 - 1;
                mouseY = event.clientY / window.innerHeight * 2 - 1;
                targetRotX = [
                    Math.PI * 0.18 + mouseY * 0.2,
                    Math.PI * 0.18 + mouseY * 0.2,
                    Math.PI * 0.18 + mouseY * 0.2
                ];
                targetRotY = [
                    -Math.PI * 0.18 + mouseX * 0.2,
                    Math.PI * 0.18 + mouseX * 0.2,
                    0 + mouseX * 0.2
                ];
            }
            window.addEventListener('mousemove', handleMouseMove);
            return ({
                "HeroBg.useEffect": ()=>{
                    window.removeEventListener('resize', handleResize);
                    window.removeEventListener('mousemove', handleMouseMove);
                    mountRef.current.removeChild(renderer.domElement);
                    renderer.dispose();
                }
            })["HeroBg.useEffect"];
        }
    }["HeroBg.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: mountRef,
        style: {
            width: '100vw',
            height: '100vh',
            position: 'fixed',
            left: 0,
            top: 0,
            zIndex: 0,
            background: 'transparent'
        }
    }, void 0, false, {
        fileName: "[project]/src/app/hero-bg.tsx",
        lineNumber: 156,
        columnNumber: 10
    }, this);
}
_s(HeroBg, "V9/qkEdV8GfsDZk7lMTA1T8g5Ps=");
_c = HeroBg;
var _c;
__turbopack_context__.k.register(_c, "HeroBg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_hero-bg_tsx_ee512ddc._.js.map
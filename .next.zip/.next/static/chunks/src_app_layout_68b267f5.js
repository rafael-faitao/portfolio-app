(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_scss_3f5efc03.css",
  "static/chunks/node_modules_next_dist_01fcdebf._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_three_build_three_core_df0bde7e.js",
  "static/chunks/node_modules_three_build_three_module_230a9f89.js",
  "static/chunks/node_modules_three_examples_jsm_989a2a38._.js",
  "static/chunks/node_modules_next_dist_compiled_react_26ec58f1._.js",
  "static/chunks/src_app_b4b1c6d8._.js"
],
    source: "dynamic"
});
